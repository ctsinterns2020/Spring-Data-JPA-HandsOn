package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.repository.MenuRepository;

@Service
public class MenuService {

	@Autowired
	private MenuRepository r;
	
	@Transactional
	public List<MenuItem> getAdminMenuList(){
		return r.findAll();
	}
	
	@Transactional
	public List<MenuItem> getCustomerMenuList(){
		return r.findSelectedItems();
	}
	
	@Transactional
	public MenuItem getMenu(Integer id) {
		return r.getOne(Long.toString(id));
	}
	
	@Transactional
	public void modify(MenuItem a) {
		r.save(a);
	}
}
