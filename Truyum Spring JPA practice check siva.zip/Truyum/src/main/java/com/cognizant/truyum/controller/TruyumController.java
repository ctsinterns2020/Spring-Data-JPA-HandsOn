package com.cognizant.truyum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuService;

@Controller
public class TruyumController {

	@Autowired
	private MenuService s;
	
	
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String adminMenu(@ModelAttribute("menuItem") MenuItem m,ModelMap modelMap) {
		List<MenuItem> admin = s.getCustomerMenuList();
		modelMap.put("a", admin);
		return "admin";
	}
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String customerMenu(@ModelAttribute("menuItem") MenuItem m,ModelMap modelMap) {
		
		List<MenuItem> customer = s.getCustomerMenuList();
		modelMap.put("c", customer);
		return "customer";
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String editMenu(@ModelAttribute("menuItem") MenuItem m,ModelMap modelMap) {
		s.modify(m);
		return "customer";
	}
}