package com.cognizant.truyum.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.model.MenuItem;

@Repository
public interface MenuRepository extends JpaRepository<MenuItem,String>{

	@Query(value = "SELECT * FROM menu WHERE id=1", nativeQuery = true)
	List<MenuItem> findSelectedItems();
	
}
