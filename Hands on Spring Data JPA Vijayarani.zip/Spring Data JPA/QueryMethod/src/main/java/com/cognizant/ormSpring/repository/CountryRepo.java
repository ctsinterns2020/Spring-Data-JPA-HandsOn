package com.cognizant.ormSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.ormSpring.model.Country3;

import java.util.*;

@Repository

public interface CountryRepo extends JpaRepository<Country3, String> {

	@Query("select c from Country3 c where c.name like 'South%'")
	List<Country3> findMethod();
	
}