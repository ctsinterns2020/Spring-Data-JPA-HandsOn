package com.Hql;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.Hql.Repository.EmployeeRepository1;
import com.Hql.model.Employee1;



@SpringBootApplication
public class  HqlMain{

	
	private static EmployeeRepository1 emprepo;	
public static void main(String[] args)
	{
	ApplicationContext context = SpringApplication.run(HqlMain.class, args);
	emprepo=context.getBean(EmployeeRepository1.class);
    
	//testHQL();
	System.out.println(emprepo.getAverageSalary());
	}

public static void testHQL()
{
	List<Employee1> obj=emprepo.getAllPermanentEmployees();
	
	for(Employee1 emp:obj)
	System.out.println(emp.getName());
	
	
}

}