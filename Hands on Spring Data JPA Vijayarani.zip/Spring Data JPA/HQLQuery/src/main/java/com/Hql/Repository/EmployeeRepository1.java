package com.Hql.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hql.model.Employee1;

@Repository
public interface EmployeeRepository1 extends JpaRepository<Employee1,String>{

	@Query(value="SELECT e FROM Employee1 e WHERE e.permanent = 1")
    List<Employee1> getAllPermanentEmployees();
	
	@Query(value="SELECT AVG(e.salary) FROM Employee1 e")
    double getAverageSalary();
}
