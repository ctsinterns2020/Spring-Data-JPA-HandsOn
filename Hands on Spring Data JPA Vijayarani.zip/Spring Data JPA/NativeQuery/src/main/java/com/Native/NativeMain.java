package com.Native;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.Native.Repository.EmployeeRepository1;
import com.Native.model.Employee1;



@SpringBootApplication
public class  NativeMain{

	
	private static EmployeeRepository1 emprepo;	
public static void main(String[] args)
	{
	ApplicationContext context = SpringApplication.run(NativeMain.class, args);
	emprepo=context.getBean(EmployeeRepository1.class);
    
	testNative();
	
	}

public static void testNative()
{
	List<Employee1> obj=emprepo.getAllEmployeesNative();
	
	for(Employee1 emp:obj)
	System.out.println(emp.getName());
	
	
}

}