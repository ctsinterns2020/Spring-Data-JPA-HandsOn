package com.cognizant.ormlearn;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.*;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.CountryService;

@SpringBootApplication
public class OrmLearnApplication2 {
	public static void main(String[] args) {
		
				
		ApplicationContext context = SpringApplication.run(OrmLearnApplication2.class, args);

		
		CountryService conrepository = context.getBean(CountryService.class);
		conrepository.testcountry();

	
	}
}

