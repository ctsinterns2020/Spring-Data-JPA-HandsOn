package com.cognizant.ormlearn.service;

import com.cognizant.ormlearn.repository.*;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.*;

@Service
public class CountryService {

@Autowired	
public  CountryRepository countryrepos;
public void testcountry() {
	Optional<Country2> con=countryrepos.findById("IN");
	
	System.out.println(con.get().getName());
	
	
}
	
}
