package com.spring.service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Employee1;
import com.spring.repository.EmployeeRepository1;

@Transactional
@Service
public class EmployeeService1 {

	@Autowired
	public EmployeeRepository1 emprepo;
	
	@Autowired
	private EntityManager em;
	
	public Employee1 get(int id) {
		Employee1 obj=em.find(Employee1.class, id);
		
		return obj;
	}
	public void Save(Employee1 emp) {
		emprepo.save(emp);
		System.out.println("employee saved");
	}
	
	
	
	
}
