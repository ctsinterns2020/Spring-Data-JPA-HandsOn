package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.model.Department1;
import com.spring.model.Employee1;
import com.spring.repository.DepartmentRepository1;
import com.spring.service.DepartmentService1;
import com.spring.service.EmployeeService1;



@SpringBootApplication
public class ApplicationMain {
private static EmployeeService1 empser;
private static DepartmentService1 depser;
	
public static void main(String[] args)
	{
	ApplicationContext context = SpringApplication.run(ApplicationMain.class, args);
	depser=context.getBean(DepartmentService1.class);
	empser=context.getBean(EmployeeService1.class);
    
	testGetDepartment(10);
	}

public static void testGetDepartment(int id) {
	depser.getDepartment(id);
	
}
}
