package com.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.spring.model.Employee1;


public interface EmployeeRepository1 extends JpaRepository<Employee1, String>{

}
