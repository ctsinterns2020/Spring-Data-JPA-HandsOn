package com.spring.service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Department1;
import com.spring.model.Employee1;

import com.spring.repository.DepartmentRepository1;

@Transactional
@Service
public class DepartmentService1 {

	@Autowired
	public DepartmentRepository1 deprepo;
	
	@Autowired
	private EntityManager em;
	
	public void DepartmentSave(Department1 dep) {
		System.out.println("department started");
		deprepo.save(dep);
		System.out.println("department saved");
	}
	
	public void getDepartment(int id) {
	Department1 obj=em.find(Department1.class, id);
		
	System.out.println("Department Name:"+obj.getName());
	System.out.println(obj.getEmployeeList());
	
		
		
	}
	
	
}
