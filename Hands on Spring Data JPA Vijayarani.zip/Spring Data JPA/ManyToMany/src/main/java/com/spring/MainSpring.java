package com.spring;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.model.Employee2;
import com.spring.model.Skill2;
import com.spring.repository.EmployeeRepository;




@SpringBootApplication
public class MainSpring {
private static EmployeeRepository emprepo;


public static void main(String[] args)
	{
	ApplicationContext context = SpringApplication.run(MainSpring.class, args);
	
	emprepo=context.getBean(EmployeeRepository.class);
    
	//emprepo.insertDetails();
	emprepo.retrieveDetails();
	
	}



}
