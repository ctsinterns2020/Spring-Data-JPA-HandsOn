package com.spring.repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.Employee2;
import com.spring.model.Skill2;

@Transactional
@Repository
public class EmployeeRepository {
	@Autowired
	private EntityManager em;
	
public void retrieveDetails() {
		
		Employee2 emp =em.find(Employee2.class, 1088);
		
		System.out.println("Employee name: "+emp.getName());
		
		System.out.println("Skill: "+emp.getSkillList());
		
	}
	
	
	
	
	
	
	public void insertDetails()
	{
		Employee2 emp=new Employee2();
		emp.setId(1088);
		emp.setName("Ganesh");
		emp.setSalary(92125.23d);
		emp.setPermanent(true);
	    emp.setDateOfBirth(null);
	    
          Skill2 sk=new Skill2();
  		sk.setId(112);
  		sk.setName("Singing");
  		
  		
  		em.persist(emp);
  		em.persist(sk);
  		
  		System.out.println(emp+" "+sk);
  		emp.addSkill(sk);
  		sk.addEmployee(emp);
  		
  		em.persist(emp);
		
		
		
		
		
		
	}
	
}
