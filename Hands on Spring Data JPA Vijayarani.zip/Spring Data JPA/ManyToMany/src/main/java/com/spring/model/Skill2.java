package com.spring.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="skill")
public class Skill2 {
	
	@Id
	@Column(name="sk_id")
	private int id;

	@Column(name="sk_name")
	private String name;

	@ManyToMany(mappedBy = "skillList")
    private List<Employee2> employeeList= new ArrayList();;

	public List<Employee2> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee2> employeeList) {
		this.employeeList = employeeList;
	}

	public void addEmployee(Employee2 obj)
	{
		this.employeeList.add(obj);
	}
	
	
	
	@Override
	public String toString() {
		return "Skill [id=" + id + ", name=" + name + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
