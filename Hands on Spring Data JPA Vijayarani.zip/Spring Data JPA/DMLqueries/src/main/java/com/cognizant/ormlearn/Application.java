package com.cognizant.ormlearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import java.util.*;

import com.cognizant.ormlearn.model.Country3;
import com.cognizant.ormlearn.repository.CountryRepo;

//import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@SpringBootApplication
public class Application {

	private static  CountryRepo country;
	public static void main(String[] args) {
		
				
		ApplicationContext context = SpringApplication.run(Application.class, args);
		 country = context.getBean(CountryRepo.class);
		//testretrieve();
		//testinsert();
		 //testUpdate();
		// testdelete();
		 listretrieve();
		 

	
	}
	public static void testretrieve() {
		Optional<Country3> countryOptional=country.findById("CN");
		Country3 coun=countryOptional.get();
		System.out.println("Country Name"+coun.getName());
	}
	
	public static void testinsert()
	{
		Country3 con=new Country3();
		con.setCode("SK");
		con.setName("South Korea");
		country.save(con);
		System.out.println("inserted");
	}
	
	public static void  testUpdate() {
		Optional<Country3> countryOptional=country.findById("US");
	    Country3 coun=countryOptional.get();
		coun.setName("America");;
		country.save(coun);
		System.out.println("updated");
	}
	
	public static void  testdelete() {
		Optional<Country3> countryOptional=country.findById("UA");
        Country3 coun=countryOptional.get();	
        country.delete(coun);   
        System.out.println("deleted");
	}
	
	public static void listretrieve() {
		List<Country3> countryOptional=country.findAll();
	    for(Country3 obj:countryOptional)
	    {
	    	System.out.println("code:"+obj.getCode()+" name:"+obj.getName());
	    }
		
	}
	
}

