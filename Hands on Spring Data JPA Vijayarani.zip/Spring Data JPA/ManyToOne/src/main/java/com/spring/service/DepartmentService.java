package com.spring.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Department;
import com.spring.model.Employee;
import com.spring.repository.DepartmentRepository;

@Transactional
@Service
public class DepartmentService {

	@Autowired
	public DepartmentRepository deprepo;
	
	public void DepartmentSave(Department dep) {
		System.out.println("department started");
		deprepo.save(dep);
		System.out.println("department saved");
	}
	
}
