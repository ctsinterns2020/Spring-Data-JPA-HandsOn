package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.model.Department;
import com.spring.model.Employee;
import com.spring.repository.DepartmentRepository;
import com.spring.service.DepartmentService;
import com.spring.service.EmployeeService;



@SpringBootApplication
public class Application2 {
private static EmployeeService empser;
private static DepartmentService depser;
	
public static void main(String[] args)
	{
	ApplicationContext context = SpringApplication.run(Application2.class, args);
	depser=context.getBean(DepartmentService.class);
	empser=context.getBean(EmployeeService.class);
    
	DetailSaving();
	//GettingDetails();
	}
public static void GettingDetails()
{
	Employee object=empser.get(1132);
	Department obj2=object.getDepartment();
	
	System.out.println(object.getId());
	System.out.println(object.getName());
	System.out.println(object.getSalary());
	System.out.println(object.isPermanent());
	System.out.println(obj2.getId());
	System.out.println(obj2.getName());
	
}


public static void DetailSaving()
{

	Department department=new Department();
	department.setId(10);
	department.setName("IT");
	
	depser.DepartmentSave(department);
	
	Employee emp=new Employee();
	emp.setId(1078);
	emp.setName("Raja");
	emp.setSalary(72125.23d);
	emp.setPermanent(true);
    emp.setDateOfBirth(null);	
    emp.setDepartment(department);
    
    empser.Save(emp);
}





}
