package com.spring.service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Employee;
import com.spring.repository.EmployeeRepository;

@Transactional
@Service
public class EmployeeService {

	@Autowired
	public EmployeeRepository emprepo;
	
	@Autowired
	private EntityManager em;
	
	public Employee get(int id) {
		Employee obj=em.find(Employee.class, id);
		
		return obj;
	}
	public void Save(Employee emp) {
		emprepo.save(emp);
		System.out.println("employee saved");
	}
	
	
	
	
}
