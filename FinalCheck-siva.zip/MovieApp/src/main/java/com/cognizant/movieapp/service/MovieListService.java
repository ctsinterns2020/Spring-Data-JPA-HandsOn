package com.cognizant.movieapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.movieapp.model.MovieList;
import com.cognizant.movieapp.repository.MovieListRepository;


@Service
public class MovieListService {

	@Autowired
	private MovieListRepository movielistRepository;
	
	@Transactional
	public List<MovieList> getMovieListAdmin(){
		return movielistRepository.findAll();
	}
	
	@Transactional
	public List<MovieList> getMovieListCustomer(){
		return movielistRepository.findSelectedItems();
	}
	
	@Transactional
	public MovieList getMovieList(Integer menuItemId) {
		return movielistRepository.getOne(menuItemId);
	}
	
	@Transactional
	public void modifyMovieList(MovieList menuItem) {
		movielistRepository.save(menuItem);
	}
}
