package com.cognizant.ormlearn;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;

@SpringBootApplication
public class Application {

	private static CountryRepository country;

	public static void testretrieve(String id) {
		Optional<Country> countryOptional = country.findById(id);
		Country c = countryOptional.get();
		System.out.println("Country Name" + c.getName());
	}

	public static void testinsert(Country c) {
		country.save(c);
		System.out.println("Inserted");
	}

	public static void testUpdate(String id,String newname) {
		Optional<Country> countryOptional = country.findById(id);
		Country c = countryOptional.get();
		c.setName(newname);
		country.save(c);
		System.out.println("Updated");
	}

	public static void testdelete(String id) {
		Optional<Country> countryOptional = country.findById(id);
		Country c = countryOptional.get();
		country.delete(c);
		System.out.println("Deleted");
	}

	public static void listretrieve() {
		List<Country> countrylist = country.findAll();
		for (Country c : countrylist) {
			System.out.println("code:" + c.getCode() + " name:" + c.getName());
		}

	}

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(Application.class, args);
		country = context.getBean(CountryRepository.class);
		listretrieve();

	}

}
