package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.repository.EmployeeRepository;

@SpringBootApplication
public class MainSpring {
	private static EmployeeRepository reposit;

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(MainSpring.class, args);

		reposit = context.getBean(EmployeeRepository.class);

		reposit.retrieveDetails();

	}

}
