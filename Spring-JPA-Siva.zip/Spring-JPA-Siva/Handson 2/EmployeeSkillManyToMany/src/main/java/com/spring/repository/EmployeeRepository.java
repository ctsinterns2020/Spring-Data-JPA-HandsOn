package com.spring.repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.Employee;
import com.spring.model.Skill;

@Transactional
@Repository
public class EmployeeRepository {
	@Autowired
	private EntityManager em;

	public void retrieveDetails() {

		Employee employee = em.find(Employee.class, 1088);
		System.out.println("Employee name: " + employee.getName());
		System.out.println("Skill: " + employee.getSkillList());

	}

	public void insertDetails() {
		Skill skill = new Skill();
		skill.setId(101);
		skill.setName("Coding");
		Employee employee = new Employee();
		employee.setId(26);
		employee.setName("Siva");
		employee.setSalary(12000.0d);
		employee.setPermanent(true);
		employee.setDateOfBirth(null);
		employee.addSkill(skill);
		skill.addEmployee(employee);
		em.persist(skill);
		em.persist(employee);

	}

}
