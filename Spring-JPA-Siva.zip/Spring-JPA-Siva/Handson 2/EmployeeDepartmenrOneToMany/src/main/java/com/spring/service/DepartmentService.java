package com.spring.service;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Department;
import com.spring.repository.DepartmentRepository;

@Transactional
@Service
public class DepartmentService {

	@Autowired
	public DepartmentRepository deprepo;
	
	@Autowired
	private EntityManager em;
	
	public void DepartmentSave(Department dep) {
		System.out.println("department started");
		deprepo.save(dep);
		System.out.println("department saved");
	}
	
	public void getDepartment(int id) {
	Department obj=em.find(Department.class, id);
		
	System.out.println("Department Name:"+obj.getName());
	System.out.println(obj.getEmployeeList());
	
		
		
	}
	
	
}
