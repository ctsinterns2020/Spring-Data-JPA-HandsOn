package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.service.DepartmentService;

@SpringBootApplication
public class ApplicationMain {
	
	private static DepartmentService department;

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(ApplicationMain.class, args);
		department = context.getBean(DepartmentService.class);
		testGetDepartment(10);
	}

	public static void testGetDepartment(int id) {
		department.getDepartment(id);

	}
}
