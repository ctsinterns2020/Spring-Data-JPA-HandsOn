package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spring.model.Department;
import com.spring.model.Employee;
import com.spring.service.DepartmentService;
import com.spring.service.EmployeeService;

@SpringBootApplication
public class Application {
	private static EmployeeService employservice;
	private static DepartmentService departservice;

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Application.class, args);
		departservice = context.getBean(DepartmentService.class);
		employservice = context.getBean(EmployeeService.class);
		DetailSaving();

	}

	public static void GettingDetails() {
		Employee emp = employservice.get(1132);
		Department dep = emp.getDepartment();

		System.out.println(emp.toString());

		System.out.println(dep.toString());

	}

	public static void DetailSaving() {

		Department department = new Department();
		department.setId(1);
		department.setName("CSE");
		departservice.Save(department);

		Employee emp = new Employee();
		emp.setId(1);
		emp.setName("Sankar");
		emp.setSalary(12000.50d);
		emp.setPermanent(true);
		emp.setDateOfBirth(null);
		emp.setDepartment(department);
		employservice.Save(emp);
	}

}
