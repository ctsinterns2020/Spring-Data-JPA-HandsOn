package com.cognizant.ormSpring;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import java.util.*;

import com.cognizant.ormSpring.model.Country;
import com.cognizant.ormSpring.repository.CountryRepository;


@SpringBootApplication
public class Application {

	private static CountryRepository country;

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(Application.class, args);
		country = context.getBean(CountryRepository.class);

		List<Country> con = country.findMethod();
		for (Country c : con)
			System.out.println("code:" + c.getCode() + " name:" + c.getName());

	}

}
