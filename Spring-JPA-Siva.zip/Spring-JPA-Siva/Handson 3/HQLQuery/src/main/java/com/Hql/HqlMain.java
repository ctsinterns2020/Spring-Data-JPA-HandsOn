package com.Hql;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.Hql.Repository.EmployeeRepository;
import com.Hql.model.Employee;

@SpringBootApplication
public class HqlMain {

	private static EmployeeRepository employreposit;

	public static void testHQL() {
		List<Employee> emplist = employreposit.getAllPermanentEmployees();
		for (Employee emp : emplist)
			System.out.println(emp.getName());

	}

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(HqlMain.class, args);
		employreposit = context.getBean(EmployeeRepository.class);

		System.out.println(employreposit.getAverageSalary());
	}

}