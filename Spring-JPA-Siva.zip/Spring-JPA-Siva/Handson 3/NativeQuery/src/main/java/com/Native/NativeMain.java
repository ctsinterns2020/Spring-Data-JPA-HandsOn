package com.Native;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.Native.Repository.EmployeeRepository1;
import com.Native.model.Employee;

@SpringBootApplication
public class NativeMain {

	private static EmployeeRepository1 emprepo;

	public static void testNative() {
		List<Employee> emplist = emprepo.getAllEmployeesNative();
		for (Employee emp : emplist)
			System.out.println(emp.getName());
	}

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(NativeMain.class, args);
		emprepo = context.getBean(EmployeeRepository1.class);
		testNative();

	}

}