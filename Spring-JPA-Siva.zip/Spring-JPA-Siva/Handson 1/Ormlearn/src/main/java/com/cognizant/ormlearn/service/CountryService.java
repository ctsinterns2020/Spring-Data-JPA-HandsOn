package com.cognizant.ormlearn.service;

import com.cognizant.ormlearn.repository.*;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.*;

@Service
public class CountryService {

@Autowired	
public  CountryRepository cr;
public void testcountry() {
	Optional<Country> country=cr.findById("IN");
	
	System.out.println(country.get().getName());
	
	
}
	
}
