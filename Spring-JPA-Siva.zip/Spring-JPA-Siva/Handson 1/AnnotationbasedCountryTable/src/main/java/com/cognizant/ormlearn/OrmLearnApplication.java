package com.cognizant.ormlearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.ormlearn.model.Country;

@SpringBootApplication

public class OrmLearnApplication {

	public static void main(String[] args) {

		Country con = new Country("IT", "Italy");
		Configuration config = new Configuration().configure("dbconfig.xml").addAnnotatedClass(Country.class);

		SessionFactory sf = config.buildSessionFactory();
		Session ses = sf.openSession();
		ses.save(con);
		ses.beginTransaction();
		ses.getTransaction().commit();
		ses.close();

	}
}
