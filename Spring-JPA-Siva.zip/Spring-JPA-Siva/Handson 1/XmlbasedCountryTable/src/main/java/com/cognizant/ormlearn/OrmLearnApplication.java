package com.cognizant.ormlearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.ormlearn.repository.*;

import com.cognizant.ormlearn.model.*;

@SpringBootApplication
public class OrmLearnApplication {
	public static void main(String[] args) {

		Country c = new Country("LU", "Luxembourg");
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(c);
		session.getTransaction().commit();
		session.close();

	}
}
