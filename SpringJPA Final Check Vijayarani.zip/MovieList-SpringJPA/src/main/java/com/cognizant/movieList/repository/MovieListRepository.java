package com.cognizant.movieList.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.movieList.model.MovieList;


@Repository
public interface MovieListRepository extends JpaRepository<MovieList,Integer>{

	@Query(value = "SELECT * FROM movie_list WHERE me_active = 'YES'", nativeQuery = true)
	List<MovieList> findSelectedItems();
	
}
