package com.cognizant.movieList.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.movieList.model.MovieList;
import com.cognizant.movieList.service.MovieListService;

@Controller
public class MovieController {

	@Autowired
	private MovieListService movieListService;
	
	//ApplicationContext context = SpringApplication.run(TruyumController.class);
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String adminMenu(@ModelAttribute("menuItem") MovieList menuItem,ModelMap modelMap, HttpServletRequest request) {
		List<MovieList> adminMenuList = movieListService.getMovieListAdmin();
		modelMap.put("adminMenuList", adminMenuList);
		return "Movie_List_Admin";
	}
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String customerMenu(@ModelAttribute("menuItem") MovieList menuItem,ModelMap modelMap,HttpServletRequest request) {
		List<MovieList> customerMenuList = movieListService.getMovieListCustomer();
		modelMap.put("adminMenuList", customerMenuList);
		return "movie-list-customer";
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String EditMethod(@RequestParam("param") int id,@ModelAttribute("menuItem") MovieList menuItem,ModelMap modelMap,HttpServletRequest req) {
		MovieList MenuItemObj = movieListService.getMovieList(id);
		modelMap.put("menuItem", MenuItemObj);
		
		return "EditForm";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String SaveItem(@ModelAttribute("menuItem") MovieList menuItem,ModelMap modelMap,HttpServletRequest request) {
		
		
		movieListService.modifyMovieList(menuItem);
		
		return "EditSuccess";
	}
	
	
	
	
	}
