package com.cognizant.truyum.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

@Controller
public class TruyumController {

	@Autowired
	private MenuItemService menuItemService;
	
	//ApplicationContext context = SpringApplication.run(TruyumController.class);
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String adminMenu(@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap, HttpServletRequest request) {
		List<MenuItem> adminMenuList = menuItemService.getMenuItemListAdmin();
		modelMap.put("adminMenuList", adminMenuList);
		return "admin";
	}
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String customerMenu(@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap,HttpServletRequest request) {
		List<MenuItem> customerMenuList = menuItemService.getMenuItemListCustomer();
		modelMap.put("adminMenuList", customerMenuList);
		return "customer";
	}
	
	@RequestMapping(value = "/editform", method = RequestMethod.GET)
	public String EditMethod(@RequestParam("id") int id,@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap,HttpServletRequest req) {
		MenuItem MenuItemObj = menuItemService.getMenuItem(id);
		modelMap.put("menuItem", MenuItemObj);
		return "editform";
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String SaveItem(@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap,HttpServletRequest request) {
		 menuItemService.modifyMenuItem(menuItem);
		return "redirect:/admin";
	}
	
	
	
	
	}
