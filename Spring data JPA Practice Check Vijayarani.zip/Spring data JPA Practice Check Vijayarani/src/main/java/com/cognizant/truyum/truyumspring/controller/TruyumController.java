package com.cognizant.truyum.truyumspring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.truyum.truyumspring.model.MenuItem;
import com.cognizant.truyum.truyumspring.service.MenuItemService;

@Controller
public class TruyumController {

	@Autowired
	private MenuItemService menuItemService;
	
	//ApplicationContext context = SpringApplication.run(TruyumController.class);
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String adminMenu(@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap, HttpServletRequest request) {
		List<MenuItem> adminMenuList = menuItemService.getMenuItemListAdmin();
		modelMap.put("adminMenuList", adminMenuList);
		return "MenuListForAdmin";
	}
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String customerMenu(@ModelAttribute("menuItem") MenuItem menuItem,ModelMap modelMap,HttpServletRequest request) {
		List<MenuItem> customerMenuList = menuItemService.getMenuItemListCustomer();
		modelMap.put("adminMenuList", customerMenuList);
		return "menu-item-list-customer";
	}
	}
