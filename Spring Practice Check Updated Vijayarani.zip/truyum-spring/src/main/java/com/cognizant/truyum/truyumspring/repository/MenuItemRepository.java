package com.cognizant.truyum.truyumspring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.truyumspring.model.MenuItem;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem,Integer>{

	@Query(value = "SELECT * FROM menu_item WHERE me_active = 'YES'", nativeQuery = true)
	List<MenuItem> findSelectedItems();
	
}
